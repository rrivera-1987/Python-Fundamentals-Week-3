def login(database, username, password):
    if username in database.keys() and password == database[username]:
        print("Welcome back",username)
        return username
    elif username in database.keys() and password != database[username]:
        return ""
    else:
        print("User not found. Try Again.")
        return ""

def register(database, username):
    if username in database.keys():
        print("Username already registered")
        return ""
    else:
        print("Username has been registered")
        return username
    
    # if username in database.keys() and password in database.values() == database[username]:
    #     print("Welcome back",username)
    #     return username
    # elif username in database.keys() and password not in database.values() != database[username]:
    #     print("Invalid password for ")
    #     return ""
    # else:
    #     print("User not found. Try Again.")
    #     return ""
    # print(database, username, password) #debuggin code. Always print statements
    # print(database.values())
    # print(database[username])